#ifndef _GLOBAL_H_
#define _GLOBAL_H_

const UINT MSG_UNLOCK_ERROR		= RegisterWindowMessage(_T("UnlockErrorState"));
const UINT MSG_NONNUMERIC_ERROR	= RegisterWindowMessage(_T("NonNumericErrorState"));
const UINT MSG_INPUT_FINISH		= RegisterWindowMessage(_T("InputFinish"));

#endif